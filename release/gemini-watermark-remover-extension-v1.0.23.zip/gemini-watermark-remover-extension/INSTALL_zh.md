# Gemini Watermark Remover Chrome 插件 v1.0.23

## 安装

1. 解压这个 zip 文件。
2. 打开 `chrome://extensions`。
3. 开启“开发者模式”。
4. 点击“加载已解压的扩展程序”。
5. 选择解压后的 `gemini-watermark-remover-extension` 文件夹。

## 更新

下载新版 zip，替换已解压的文件夹，然后在扩展卡片上点击“重新加载”。

## 隐私说明

插件只在 Gemini 页面运行，会在浏览器内处理生成图片的预览、复制和下载动作。插件不收集账号、提示词、聊天内容或个人数据。为完成本地处理，插件可能会请求 Gemini 和 Googleusercontent 的图片资源。
